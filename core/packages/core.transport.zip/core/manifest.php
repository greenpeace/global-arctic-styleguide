<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'f42f64909341d135013b23c171a10441',
      'native_key' => 'core',
      'filename' => 'modNamespace/335fc06ccc3af9634d17eefbae4012b6.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => 'ea1490bfc7815f0b8f42eaa1e2296aa7',
      'native_key' => 1,
      'filename' => 'modWorkspace/4901c2bf2100e3028342187f1c882879.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => 'b397792d849ed53ef9d0c502173a0c97',
      'native_key' => 1,
      'filename' => 'modTransportProvider/537a275fd839184e140d3922f495e121.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '80cc63c18fc85560a201368def6d0b21',
      'native_key' => 'topnav',
      'filename' => 'modMenu/ebf74635811231b821615a7ab4035d96.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'f771ff87284e7f60fed1a193c65fe12c',
      'native_key' => 'usernav',
      'filename' => 'modMenu/b758ee4cae6d062dbbe1ef761615e626.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '1f626ca184227e72e28fc42b0343d221',
      'native_key' => 1,
      'filename' => 'modContentType/933b190a7494a2ff641454f404d8d7ca.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '8d0916484f0c7092dec04a43612487e7',
      'native_key' => 2,
      'filename' => 'modContentType/593ef996eb9510988a194381d781a6f6.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '093f0260748d1cc41fff12105d1ddf96',
      'native_key' => 3,
      'filename' => 'modContentType/1dcdc81037ee801b1855f21c31f5e9a1.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '67aad0e008eb52b741ddc0066b169fa0',
      'native_key' => 4,
      'filename' => 'modContentType/2bacc4da5de44d88cfceda26c3a85abd.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'aa1d428a5463e60a16f28ce10aedf07a',
      'native_key' => 5,
      'filename' => 'modContentType/a1207d08abad1f923eef828f5bd6a00a.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'c8127c36c72da4aacd5e1fdad7d7c3cf',
      'native_key' => 6,
      'filename' => 'modContentType/64e27341db9ff0700945f88e9a977dc7.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '434273f12fe5c4b0c776a1d3725690b9',
      'native_key' => 7,
      'filename' => 'modContentType/641df75899ee8644574a0394dd207fd4.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'a948108d39c2cae533bc8a35dedf2f3d',
      'native_key' => 8,
      'filename' => 'modContentType/777dffb9f4a44262d1229245f427b9c7.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '8e9afbc4fb52101243d1fa9d333772d5',
      'native_key' => NULL,
      'filename' => 'modClassMap/52df4f1980d97f5e152331ac58f71c3f.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'c4f9bce99a353d474581dc8ef1b6c411',
      'native_key' => NULL,
      'filename' => 'modClassMap/d9ce5f630e112203a5abba39257fee12.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '69a19ee9286b9a61deb2fb40bfedd368',
      'native_key' => NULL,
      'filename' => 'modClassMap/3b379a48a39d248483b5ff86ae74e923.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '30e2e4085aa125944ecff963b42a0cf3',
      'native_key' => NULL,
      'filename' => 'modClassMap/119bd4183d882c8f00355bdce552f9c6.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'e8e7b97ae49cf7ea80719d082e774f2b',
      'native_key' => NULL,
      'filename' => 'modClassMap/eaa83464d64eb91dc93806245ce93a5e.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '02fbb70df7653d9fda7d217c168500d4',
      'native_key' => NULL,
      'filename' => 'modClassMap/cb38b34774f5db55cd2b88624f3aa763.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'b0cbaa291053f6ab4f7dc51fb17810c5',
      'native_key' => NULL,
      'filename' => 'modClassMap/3c2d55aca761c1be892b6b97b03fe467.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'a71cef3edc5986800ff63ac70f4031bc',
      'native_key' => NULL,
      'filename' => 'modClassMap/f31e36438eed5c73ae95527b23485f6a.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '67e9a5a9c2f1f233dd360e1ed85fc6e6',
      'native_key' => NULL,
      'filename' => 'modClassMap/94c981a944f332eb6b1ba5f41ce1016a.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd07483b19bbbd7b727f6f401e1241cd7',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/8a261dd71517233b384bdc2a0318104c.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cee307eba44b9f8b8825f70d7385463b',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/757668e678ae9e1d4e7de23b06817e29.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '40b588255454c1895987afd75b2ab29c',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/4e79877fa48698b7738ef13ab9278594.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '50d560e61fe1c4207ac8e94edebc9c6f',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/304583ecae6bd143403ddf5c93dded47.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3ed193daf7a8a015bd83a3dac5d46cb8',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/2a195fe20103861cbd054d4148b27783.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2d6a5754ddd1499c93950e1bcf962c65',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/3c2bd23805e2a049372190ecabc25762.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e4915068e948b06a29a55cdec667159c',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/10ca4d8dade2c88b93044021acad8da2.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4c31c9e72fd9bf7084499f089976175c',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/e21d7185cc983773a968f04f704cc4fb.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '384fa9d9f01d2b5e68492ed556c3bde3',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/1bade216605b180f070ba1b747ab2a35.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3768f7902046851f55f2f5ac960d1080',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/1b4bb9a15e7ef387c953e1139098281b.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f5f1cc56ffd9c5f6d5f93aaed01010d6',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/c1b1a9761ff84a934a303e740859cc39.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '479601efd8b3e89ac5682ffb1d32fa74',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/f396357310e1afc7e077ec311a129d28.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7f3b553c52e2a2cdb1551f3f4defd972',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/a93e914417ba9f718934a87918a3fd2c.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd44bd66b51a4bb8355e1e71c831c3a06',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/3c0570f2f0a6f77e71a9f6eabf66afcd.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '699eeccecddd25f43bbfafc7a2b0b018',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/d7ef9cc89446f6b1e367c14f845ab131.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c2cc508382f5c45b9d925834bc68d9d1',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/fcd2648616ccc0afe221952c880031c6.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2032593c18c5bbff83f1fa99d9d30572',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/74bc7bed09784fded1f50f9a978c2bae.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '686ac38e92f5299bf15b9aa66b8f313b',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/d9e7656cca7303081c6c95809c79d4e3.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ecd50faee3704e8a631a6706eb6cbc44',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/6eeff9311ed5c65ccc476900a36362a1.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c9f13d498fced38a5bb463e21c53df41',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/a89f25311baaf71edf889ca1c7cefd31.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2968deeb8293a0c3b96f1506936dd922',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/c45272e3ab108aff811b67e3c02d6cac.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c686b008dc1263ad7a2a68ef090158cc',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/262383c27f1f1ae596f3f7376901e567.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'af265c7d31389660142854c0425258d8',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/8148c3c5537a168166ba1b1ff3f18301.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9f1d3c28e3b7061178839f14416fb7c3',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/ecabc5888bbd82acf4bba91f0e471758.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0c16d214fe2091488098b3d0e8b6c38f',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/745920eb879ce20b2e530afa53615fab.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c7191c1c6a83bdfce03a62690fdae38b',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/908c54eb4ef4bcea6b4dda246e94efd2.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2d96d2c7f8bc1486bea276173c0a7f96',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/aa97a85e9084883ab0632f3a2252b2ea.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c1ed968d7ef692142636b39d84c4bad5',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/da86fca4d9bff924853b3b2d1d6a2a76.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ea474429e05c2e48badc6f9f947a540f',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/22404af24a306a3e3e0f3ab725d8dcf3.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0d85c6d13111615315a1f13a0109c3c6',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/312af642c91fc4479a126638a024ee50.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '95deaed692bfcd3e59f53866f479626d',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/1b4eb5385507fcfbff4e8a5f01bf890c.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '340a5936157d9fe79fa62ef2908a4fbf',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/e715cbebfbbbb2937a5072e633ef0764.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ddfce5c2410741b1e21f68931b11103d',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/180c0d9794d86a81f6a7111013b6dd0f.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9326c9937b5e0304aad635cbe32121e2',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/a300d10c58b6aa0619e462f4400c8d95.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a46befc875c9ddf534f0fd9ed9aa80cd',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/0dad95a7184b5e7a57f0bcc251fc2d45.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e325f866cafe303aa7cb066e8d238ee0',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/bb369530cdedddd57561aeb32efac323.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '85f2fb24b2f809c0172b65ec65bc94c6',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/23471230be27c67e1a81c1ab6ac3af4a.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5c4bf771cdcabe1b94fad61d7cfd25bf',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/6f6de58ea77566f4d9dbaaaf8b965859.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '27cd55745a3cbb06f9db12459388beca',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/49efe6b7fe4b405092e795fc3f6eb666.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7185891bf1c242a8650524b4f61c036f',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/19959a04ab1a87c7509027a9fca8c987.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '75b1aed790cb7857b903e93fa527d959',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/0c7c7afbb80ffbcc560ca234eef4aacf.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '557211c6ebce45733b734844127be1cb',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/ba061e8e0de8d3c7ab7f502141f1ebf3.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd156d08ec53e3276bac888072d7b1017',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/a3f904ced9c52f03ada8dabb953f1568.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f35307814774eac8f74176a71b1e2e43',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/01ca72c00e99f27a299c5280e6112440.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd6f43d03dfc9ef2e9ebbb50dd58a0243',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/e9cd392b130e4d4480f2e1072270cd58.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aaad9070dc68e081882379cf220032a2',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/f9fbc37479b165b0225f84cbd1d010f3.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '88d47e44f1e6d82d5240fa923cd1b629',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/783cfe02e1604489c703c457a5ab57de.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4f53a6cc3a443e1dbc1014b2e8a811b1',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/6aec5e08eb65ed6bc8afd9de944f8b83.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2aa7f0c2e053c45c34f87d6c14b2cf6f',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/5ec65f18584bbcfbc7a0a63e841f3c2e.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6ad4b183f36fdabb165ac83667fab45f',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/3168a2094bf108af3bd3a4c9c5fe50fb.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '79985de6f326a13fec000c0ac02e0667',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/0d83ffd6ccdbd7c86bea4f7bcbe2aa67.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '86c0e78b7c652d534995e005f876ae63',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/23e34563fc819a27b98ea07ef8105e8e.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '49fa303e29a06e9f025372805a351022',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/bcb3004ec63b551ab2c539638ff07e1b.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '035d4eef793f10cf7ffe8645115c0221',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/27829e691b139daa90b8206a392c7914.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '656163fbc80b16d2cc3664f045088e2d',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/72d80ed31f5b0d0a9b2713bd25abeb9d.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4857759c00d1ebc114504802d2bc8850',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/57c820e8dc2f07d2475333158ffaf608.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '58ffbae2a719fb76bf41d342f923d998',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/0ecb4591b9e1e1ab11ead2d4dae52ec3.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8b809cbeecc1ac0591412dc277391e59',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/8140e8be55ea41851c2ee08a585350ce.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e1e53f3fe2e6e61a24bb87fce7b23fda',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/5f10dd487d9658dcdbcd15201981b0c3.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7715f20b2ad91668a52bd758906fc709',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/f13a906fafc7b1e87f4406df19f49c62.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '22244627c976e718d21a25eb7297195c',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/46b785b14f943517b6da21143545a8a0.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5d2a83e56c608026d97dd20444b8a725',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/f214d3a1b0f2abb53b47f09b5a64cec5.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '765923e6142579bb980461e323398e27',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'modEvent/512e33058faeff40d792df41283dc6bf.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ccd3b98beb53c1c7160b438b0420d480',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/59f0707a18187a42129274be10aef44f.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3d18c2812178873ac4ba4360f498fb78',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/e5cf1268bc4ff0385de8505b7628c4b4.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1fdd42eaf88d79d151dbb31ce35b1a70',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/60b18fb4b17c549b3c4393427ce449ab.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '57d2579d1b3ad227751e0b78202d6e63',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/c8657df45f591b14bc249e2ff5bf7126.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dd31165e2dd2de417c0292462c27c8b6',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/c51823c333fd3e202f3f4eba1dd9b1b1.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8781c94b1912aa74d078aba38f0de3ba',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/7c81c684e5ac5bc2dbaaa28a5cd648ed.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4f78535ab14ee3061a196e729b7e76fb',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/99c5c0197b8274f5695d502c9c4219be.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '561a7bea35127b662c9738bb398286b9',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/dffb780f3ad7eb8b3f7815245b272e0c.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '98e66552d44299218d91c2a917187576',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/bd4c195da36ff1a6e08e776cef373922.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8427f2abaf158e63e473e132e8195b79',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/501f3d4e32c0d97454b80e2f21d8c367.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '86dfacffa2915c5d0177694615558ba3',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/327870019eb3ccc3c7db4d58a1c0735d.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6135103dae3be31ab88942f37c6a3cf0',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/2376ee57896b7b6b17b7f81b68ca6ebb.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '288e35f3034404d18b822dcfc70a1b67',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/3f6870980d102eebd598a3738e6664ea.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fda3bd4bfbf566e8846ecd5d07f29e00',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/1df092edfada4e370abb734d63acd5b7.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'edb4769bc359d948df0c3b4a2e975fbb',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/9919e983622c0454b88ffd90e9e932cd.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '65cedb3ac0995837e15a16230837d8af',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/2e652fb0e690a54eff8bbbfd7ccc33f3.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5fd8b16fc3bd31df1f94b863de4a75c4',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/8fb50796df8804f81a3eccc054e1ec6c.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b2de80e0e53adcd660beb5b61f61d14e',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/2273d426b9b2e6cfe02728d0513675f5.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '32ba83957f697117a9d78ad243b0b8c9',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/36ab280dee90226eee6eecf00004002a.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '93e518acc12414fd5550081bd20da40d',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/932f7151c4d44c91c21b3cbe76cfe651.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8456fb7729bcbdccb561f412a839bf71',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/b9e42ab59b6491f600bcfe400d5b9955.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e3a4618953d5c392e4ba400a5c7700db',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/17de3a108651ab6dfb57188847187df6.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '629edecafd2b05ee799bfbdb0d2ead20',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/d80842ae7f70fc4cd711d17112435d76.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '57a4fe27d170bda93237d5a94cfce4ff',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/3f6c98a3f778ab845dbf80c15ca4a078.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd43aab3557e95c96cfb2ff195d0d0bdb',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/c36e065e8434dfedd004b2bd8d2fb9b7.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b3529e812ef84e1f650d8fbcf75d9873',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/8d728a77b79ecf2cb876f075f502f589.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8a44e0fc02af2e238d28621914542602',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/d30c4375f1ae34131f7b2480c60d25c7.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7bf38d9fb72ddf2238e04d2ebb0f1c74',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/0c3f8d6892df3f1094ab07ed0db6bbce.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'db3f34d7cb44d58cceec21b1ab4dff91',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/1d6ba0ebccd18f3314c9c4aecb4d1a49.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dd383265a9efa9f5b02e2687463c2b7c',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/578b4f15738105bc1c475ebf8c0aa906.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fe869e1aa029684bee5b26493401b771',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/a3cd08e823d820f2f114ab0541dea696.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ffe5a8b0b2160bc5d62a6712630f5283',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/073e12af11a28cbd6a67887646d8683d.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4c5731ed03b7964bea30318eca7f8295',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/67a2d51dccd62e449512e64e7e0c56cb.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aa9e13c49101207000ad8b65c31be175',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/cf27d0379866560fceba424d775756f0.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ce9dfc1e949a818c6f98e8b5ead34441',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/71ffa6c200e35f4311ca5c3534661f3c.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b67fa84e3162816e07a63513b68e6007',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/1418b963c31daf633c4a0b6eb14d5134.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a0a2933dc812b2ac069f7a375c220891',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/d2c264042344888f820e3236e42e38bd.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '70f798d7770dedf603b142cf76c10407',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/4240fa2ffa495550b306318092fe8a2e.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b65e4df31fc51fbf97ac3293694ab91e',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/8f1ca0e1c8f57af0c14860f32e2adbe6.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6a5a6b6c38e1d810a3e80a6b33fc985e',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/40d1559346cf9c3410923cf8a954b62a.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd19f6c60bf0b8e8f4b56bafdb98d03f6',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/a326c2618e0e024871136639bc549009.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7aad5e51df0d0ec002c8b71873513f37',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/a16174fa34a8c6b7b63b7e46bbd03f41.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '54a6ab746f47cd88c5908fbf86512add',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/60a3754920beb3444c2f83bf61adef14.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2f3769de3d8279570b118219c75e9948',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/8734cfa97c8a38afcf95c9a256ded169.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd6c8046c3a8d80b0691e31aecb68cef3',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/a42d2bcdccd80fbcd5b2228fdeb5e44a.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5fd39e7abcadb8538b6fd7fc35f58099',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/caf688743567097366250da090187430.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ce16061f98045990b9adecb484ce6bd8',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/7ab245e84dd1903cb69736807a77f116.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6f2ddd84c2b8f6fdfe618e7465840ccf',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/8ead2de0af4e1d0ab699aae235f3a1b7.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4a1c40e22ce38b11bf476b2a486ad71a',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/ef538be8b25c291351227db825e7d027.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '708d6123d813f70862c6dc000cba8051',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/7bccd3b6a786e41e3f7da2a3feffe04b.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8b3767bacd5a9df18fd7001f9da663dc',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/359ae46a6e0e886b9871c9f86e9db4a9.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '07df1f4d7b347044b3cf7cb8d5a860b9',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/0d103136d2f6adaf38d4a707fd8f627f.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1a7b7bd900e131aa5a3092c7f808c637',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'modEvent/dac65dfa0a3003acc9fd96db80098cf5.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8270329dec11d9c0bdb44a7aa9c0dcbf',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'modEvent/b2167c62555e415686c57f3e6fd15ca1.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '09d32c8e95dfbf187396850060c908ab',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'modEvent/b55b5446cf069a833bf128eacdad85ec.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '82db278bc4f1b18cc4d7004fc7531aa2',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'modEvent/7a62d71a6865c50b75dd17333c11efe2.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6eea020114dc3baca54b03604f0f9d0f',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'modEvent/d10b1138c6405f1b52fb93a0a3990c59.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ea46668bf9b56e63778c73befa16901b',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'modEvent/87bb5aa87544f3c97248c4293c1780d9.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '97017c50fd843ba6ba790196a5143375',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'modEvent/d192e78d83f2ee160cf7ef763aa86bd2.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '57d34db8e8e6203ad0d8ca8239910012',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'modEvent/0a8de6fd8b2cf664de91c38330273b7a.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cc9e777d2682041299a0fcbd355181ec',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/099377fa0ca3b8c2e0046608c58eb3c1.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a59136b5d48769d67dec7d3d174a1a6e',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'modEvent/f767a35aa5e852025a2a007737a7d029.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '65c767c9a9fb48fd92b47bee33b32bb8',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/ac3fc36e987b9c363110c03c8ef09817.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd088a627491a9d828e720dfebf97c1d0',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/52b854796cc74c3323f700d51c1c30bd.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0cbe101bd21955a7a37b2aa1f04b04b4',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/279184e0a83b4dec57cfdfda729644cb.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e4e6747d62939778b8ccc474e1e24d2b',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/9a310c489a5d7e0e06fe1c6e634d3b9f.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b17ed8293176d12b853f0afa06ddc848',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/152cb0cf5ae03e39503e06ee8a97dc9c.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a39041b5bed3de98eb08f149056ee885',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/541ff2707ffa659b488b0d14e7786f31.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f81a380005f92048b704920efc83d93f',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/7e46b02cb07713d62e18c2290523e101.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4101158ea284052f48856e41c517229d',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/bddca39666bf4dfd6df5928fcd0e6b06.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '55df3e1e7c7ba86d7c441b704e9e095d',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/8f9ac93ae656293238e9daed2221a60d.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4589950186b2f238a675eb4e3527ffad',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/6ccc79659e5971c7f5b725f01cecb36f.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b2961649ee7e3a42eb12fd7f7fe3847e',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/7a7c1f2717b36ffa1ccd553d46a0d1d6.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e17b46da25dbfeb7318d7e5635351661',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/44b7af7ab7e077b5d101b30f57faa03c.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c9ae212e17a2388bf22210331b8bc6cf',
      'native_key' => 'OnMODXInit',
      'filename' => 'modEvent/6b387225038ba1a67df9d34b9f88e30c.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd05fe591b074e5ae1f06b18fb0f3fec9',
      'native_key' => 'OnElementNotFound',
      'filename' => 'modEvent/ebe8ceedd77f14920162b48f4e73d2a5.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0703dbb8c02757bba5d8057a9c25bd50',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/7ea7557cfaa646bc50e5a0f96d1ae9ba.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'db6b72a660fb52b1a9a9ba368094f6a0',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/e713c1d1128090e51f496631301b4b80.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1e5070c582c7b4e7867d787b44d18add',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/57b99870464477d91943d50fcd60a441.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dee29c2c34bdd55eb1e8c14cb9897f8c',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/f4b4a0322497780138938d35efad2dfa.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1f880bf9e07ec32b5d1df05bb410d23d',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/339085ff2437bcb29e24619e9a84ad1d.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '11af1094cc2ceb5df93f5c2023d7d2a2',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/931487855ef738120b3055e6aadbfc9c.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '81ba0d3eac45b860d9ac179904cec893',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/7896c5efc798a49dcdeacf5d6ca954b1.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '165b6365e4d846fba26ffd062326c137',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/6819b7d5f6dc69dcbd33f0786bd6f642.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f47143c3f28fffcdcab290f94cc08e20',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/b8002d903d63dfa1dab155a5088d6300.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1ce93b8832735831f74e51324c7547dc',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/3932eb8e65991af59dddbb3e8ff32cf2.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1c6ea16405fc1adc34cf62ec32636b3c',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/37c765e7e2202daf6d815f5c329d9ad1.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b68c2b4576255e6113f61a931d0da07c',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/83d0ef3e4845907e63ed5dae43070684.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5e3fb2ce58dd6546a4ffe7ece6d660a2',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/998feb7f69e9cde932f405ae249dc84a.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '107070945acb43612026c849561ef9c7',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/e1593a5e8a47ed644228100844c06e7f.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '490117a035efecf2def93baa46aabd2e',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/e54825016c51807d0c445dc0a75ec983.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '188d5571242526b7bede7c53028ce73e',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/edceba287380771c5b017bcd07db06cc.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '84a25a6d44532858a34464424cd46797',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/e0846e47ecf957ded1542352b94e2ba1.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7c1fb65c14542252f23d29d47cdb20d7',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/93e709d4510eaeb12e1d474ce0a5ba1d.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3548112e9bca20ad54d2ee0e3c486dfe',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/3cc854d07448d742a91cb8650253741a.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd7359f61fc9a92657d4d6b5c8ad32887',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/a7ed81107dc32fdef9bb9f79e5b90363.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '43389c52dbc8f476b3ada7b6047a460a',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/886806cd29d308effeeb2f64512535e8.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '243960b388cc493613300fcb637478f8',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/0124167a9586134db0faf63d493bf7e7.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ec6dac2cac5d5d4cec9a3e12ede20d1b',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/7eb38336994c88ec8225009d9b91ade9.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5a9efb14bb4d9dd81a36a4ca64bb08d2',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/b1e0aa131bd5833d12d368c58947e9c4.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a6b7b9858f0647c3fc3e84246a337393',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/e6ef0a71fa056284c5e55f9824ab6327.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd4d242fd5019df6011f48103f82c1335',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/21e7069be137182f3a6bd74bf9016178.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd18027f89c3616c0f96df4bdbbd36610',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/bd4dcff7e2fa12e787de0394f7293b96.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e02b362e8ddefbb0dcd0bea8993a2d35',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/893bcba884b87e25437a12de30b7919a.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ac5a4d229361f2e75152db4699174e52',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/0fb90007fb01ab575fc6f0d5422ca76e.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '862e5ca2735d049e10051aaf11567dab',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/b02b052409a0a1eccba95207ab02a14e.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1cb0e788651eacfbebded88de1b8a6a6',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/23e376344845dbdabf3877871394f1e9.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '41d4fa305877ebc3508c04b526639c32',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/cf17eefa090acd95f2617db1f0aaee7c.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e412ff813c8ba1c6d4e2b51cc80ab718',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/2d8d8a43362c831572e5c03bf8f645b1.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '30666bfbe7789f9a5b350a4724f6f071',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/db3362e76b40dc2f9b548b54a08cf01d.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd6b1640e430220e13bab0bd00f8258b5',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/931376be3bd7c5c4d13c0563c3d86292.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '53ae848f593d6ec95b9fe6e7eb6b9f90',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/45deb9dad4d3598e44fb24fa2f7562c0.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f68ca0343f8b7be66350888941221abd',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/fd4eb6ef67708624feb5d0e15be4996b.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '92acce64ad4aea0cf3e7f90ec5f8cf26',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/f5ef5d455bc33534a8297d4d93ef597a.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '76f8576f1dbdc8c9fd0395f3f6ea8272',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/6d9aa88eccf13af6489a73542ab0dde3.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '092de1865b6f58917f3c29ee54a54a2a',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/8ad439dd50b6d5d8771441d3bb4e6fa8.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '760da98f605ee703fa1b659d07737a6d',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/9a25c4789ee5245b06c4bc9fd981f55c.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ecb7648708e5f11e9e2866787c02f759',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/9632d5729bd3c6974392e3faba7e0d6e.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bc102e8407499c584e23a856e536d4f6',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/2db96c7650be082cb15c350536ff4a5e.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '888efe37c37dc9d5c4f86a1ee8156785',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/bb78e4347130dcfabcd333e6c726cc86.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7ac25be44d3fa6fcf835d5e76a87a6af',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/4b04c6d3ddb173c352db7733ea610dab.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a05e271393ba677d5fdc370c0edb5ad5',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/3946cdffe5263b7e56419d76fd432393.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '872faad3713a8ee9e68c927926c557ca',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/a894174960a90aa5c50ba83956d29126.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f0ee65f3e85983805957fa948492ba8c',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/95212c669f5df77bc4c28feba45b7da1.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '872b62b345a2b376ed9550d3e833b54a',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/7af9d7e86e40e93d7df0f4fd44cb9fee.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3c14e5395a65a5af04cf372db4e62ec2',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/1d774b12d6bb869446676c414eb8a621.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f8fb9b4be712adb4bf5c393f96d095c2',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/5bd38e5fcd3a860beff7d63cc6fe642f.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5736e88338edf9c14c5b52695c8fdd17',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/8c305386e4e23a5ed7a10edcfbdf1a10.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5d94667ba56d3a2b6f2f86ec3dc2307d',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/cf059d8106a3445ea14572f313aea4fb.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9d9e035bc755667b6ee3dd5c41631177',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/cccd847f4a0228ed0d7aa5d06c4864a7.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bfe0b8849849aab509d1df99e55c8cde',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/9c188a43c56b77b940470ad84e98871b.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '616a314b75370f3addf35501324ba01e',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/e3ddcb6c5afbb02fec072771e0c9ac57.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '72db11b92560dcd4c4848deefe14ef66',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/94fc1e5da1d31d9a31aa4171e473240e.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4ffc693382dcc970d6beeaf64a0a9193',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/33daa59017fa70c293f6f85610c74475.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ed494fc97528b4b2138fed29e2bef10a',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/07e0957868567e4dc0901c8ec52c0495.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fecd1183701f7575b6e50e57508bb429',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/1289df5361b2500775a091fa7fdc8387.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a74290c89daace47fe549580684af6f4',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/50d03bcff8aff6e499cdb6d7366e0ba0.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fcd9cfbec37ac35c1279e6e909d8bf10',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/ea58b0615abc9a95d33f1c0f031dc93d.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cd4d67755b40c14f4cc1f161f011cd8e',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/9d3cf2ea654226399f3dbc7fcff4f072.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7c033b41619184effbf679e999ce191b',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/8dbf63ccb0798ad5275c3066cd4fbc87.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3381a1dd9cbe9bc5310e5f91fdfcc83d',
      'native_key' => 'cache_disabled',
      'filename' => 'modSystemSetting/2a93b69da964fedae5bc90306cfb0ada.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '13c5f192e1d6bd708d0d0eca15702855',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/60fb50feebc5f9c6c69d9464150936d4.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a71d8c0d2055510bed25417fbba72ee0',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/9332de295b62f7182a67de906bdc09d9.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2d7ed61f9c38756fc99be2199b465c75',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/b8ed0658dd40950516a60e61e1c5c2e5.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a87d8af2076783c396029fcaa4de956d',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/21a4ef331658b64b7013187135924d71.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '20d6a24011243cc0ccd02a04af2023e9',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/3961a14520118c3aa474cd2ee642f2ea.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2a3852d3a9e2ff3142b7f5cac62624e1',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/592ebce7f30c3819f328546ae7554a51.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '543c281b0dfb7bcbd865eacc7bc39bda',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/fb2a3af21217b74967f307d74c27e8c0.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c7a813f6a45ed186ca20d1fcd9477540',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/c2c111fcab44e9a5fcda422ccf2d6e05.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7097f2962d4ff97e2a28ca8bfb828c35',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/ba099efb53cb8f30d92d5d5909b7365b.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '117e0df87805d132783cd29598fd205f',
      'native_key' => 'cache_system_settings',
      'filename' => 'modSystemSetting/df7bb4259b89e8b8327272880ab3d74c.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'be48af66eb5258b11241f90aa3d011b4',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/746bdbe133497fb94c64f73c8e8eed57.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cba9bffbec3ba2bf89bb62abd4eee29d',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/78e941f7f22dcd594e220b785bc10af3.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '43269f3db64ea6cf5559f4473c22f8ae',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/fa87446f259faa2f0ed9e0cb9ebec78d.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '67485aa017985a1a3c1ef9d83a1b0d24',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/4bb4c2135ce896d85b855df80734393a.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b23e9672638e605d5105c3623033c75c',
      'native_key' => 'compress_js_groups',
      'filename' => 'modSystemSetting/44eea02f82698e607abbb9025368cb4e.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ddd9b2335f81de098d3d143d05cba15',
      'native_key' => 'confirm_navigation',
      'filename' => 'modSystemSetting/7446c355113ef210e46295af0f701aeb.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '56b9747f9c16134f33ac414986a7ea21',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/e009ceb704d1e75658e746cdd965038a.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3934620206d1d84f8bc931ea4f6f56fe',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/ef0d9079e630e3cc686616b550eb7139.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '12d9de40ff4da79065b09e6b4ff12390',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/d6125febcf829320280eed1791e392dd.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2d880b091f187b32fa03d102eac89e96',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/d1e216f09b2865301f7266a8c8b33524.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '69e1175be74c1c7d5de45a76579e9ae3',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/10416f19c7514eeda9a37444e0f2890b.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca045c53b45ce03c2b27af022a821542',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/ee4f129e6af3802b17e38c6f68afacfd.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '87c52afcf76f2bd88e9df1920201c702',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/8f2601e612f75e256276d8b703fe4561.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'de0a632aac2c5cbc211197010c940b93',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/b5986a5e59db70782655f9e02c6d4d9a.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b5ea9d920d4fbe77bf12f64e894fe40b',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/955634aecbf84560eeb37e1e106cef8b.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '80a03e1dd1c5f536e19dba51d7daf907',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/ad93723064a49764a35bdea7a2a923d1.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3af45810f317378d68b9d8dcea63938a',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/caf472ec9ba00af695da31b1c6ae5c82.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eaa34a60d09712fc2f0721e2f1a0bb81',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/e3fb3d79b73c1eb30e2ac88e9e1c805a.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9a54c5f896637e72192e5ed25a113911',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/48d9cb1ec867b4abc95f5029d27a66bf.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '42a4c4779dfcee468703708b31aaed00',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/956a66c73ab25ee48d0254f1222c2fe6.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e890028043e42ec232ed779e8016fdbc',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/db3a0656c2231da1df2a2930c47d3a87.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '280fff8998b87b7a78e1c3918341a62e',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/e639d91e3c80f22fe7fe0f1aa28f2413.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b761a34397cbeee2aa47fd5828c14e40',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/682c34ccbd66e2d96d0d358314c8b38c.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '633c34e2e0266888785e6ec05886308c',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/6bd6a39666ec71865b0862d14d5753b2.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd28403ae776708ed4286b419e5cba031',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/d6004b9132f4887e8873a94a3dbf129b.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7daf164c5a2e1909da805c6b35ff6a80',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/0ded7ad6d002bc89c95f4256be48cb05.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0913d568eca9146098557240d1542968',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/7209d69b959e630fc1632efa95115efc.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e183fc34a78f02b7069c48c2c7a6f87d',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/47dccfd858c529197d36e3fb4d2aba92.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '17636c8f94014b3b26a8189ca2d968a5',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/5d4bb33fcdf8e0d2da74b5f1de4e8fdb.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9c6015ccef78f68c96060cdf8a5c4b6f',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/4c3d588e8cacff8286b8773a150b72c3.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4f1be8bc4312c3d78b556d66ceec184f',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/9027371c0797d3fd096e2541a9031f06.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c5767d6cacf7797927219a30136f87ec',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/2e52799a464ac8350e773b015c80cb08.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '81d8af13e5913da380e19524bb2aa6f8',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/75ca5ccca740b5141f4c032c47dbc3a6.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '158e0e64e53023993bff057692dfdbc7',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/82ff7e8a1d5ea49c3f6a9efe0fc7be90.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '70920398b3044ab34afe431367a3ed56',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/15689bb1cca9c90255bbfd4fe87ee900.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '229f524053558fd8a52c39b91f5224a2',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/ec7ef2fc8a7bc81e597cbf6fe0d115c3.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0af181de33b229bdb81086894809c43f',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/9b6b6323adcedc7810e27348325ae24d.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e43b679ec82ff028489b848bbcbbac4c',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/6ca1be34144621a7aba2a55027e65747.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '48016f4305a0f7bde88dd28b65fb07df',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/d1fd7af265586315d05e3ad432804221.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9fa1992cf4181295ccb69f331ca8f885',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/a1786e0ad35d452cbb1f701ae91bbb2a.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '93992a65cd95535722416d44230190ea',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/039d9013a5bcdfd26452338fc940a38e.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '819793803cbf946a172916c7dc1f851a',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/9b8a48f6d86aa7291abdf3731d4d8bcc.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '610f18e5f0bff80d045c517ac4d91582',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/d571e136d03a0ff39b0e6a12a9a63dfd.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '150fe486d9857b30d8b7acbb8aca5498',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/405d3083994a6c7b7e536b8f6ea7f285.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1ac1e8f277ebda94dc4f2a5e61cd3baf',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/023b8ba7c8ee944cb32e8b1ac75e5bbe.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd55c863809fa495d64732eac3091ca7a',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/25b256b39c735b275ce31d5baf758cf0.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c6fb7fbe2a6051cf078126f26b2cd0ff',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/4d9b086eadca2104a94361d38e7aae21.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc6a7b5c11731a3619768fa4fb792e35',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/38bd05d70a55a6bf0a770787bfe0c42b.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2aa86048f1d418e23e6e514864c228a5',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/61d569018d05c06f661cca3db9d0d85e.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c0ec4e3ee28ae779564157ff67cd69cc',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/549fd8c69ab898dd3683019a440beee2.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '50cafa7ea87318a7ce3c9e9f080d1855',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/31a84a430f7c0b54851ddc033ebb407e.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '95424cd0c1919ac0fe83abea58cac372',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/d57913795285bb3ffee10f78a6c3c5e7.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '79749024e6645c47eb48f6a4417bd0cb',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/a10b0c7c62e5fc106a28ea8619b81d90.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '43de9ec3c05bab034f104838352ceba6',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/971775fb88bacc8fbcb79c9742f2610d.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '588341f044e42ed851942ac00ab1bfed',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/80807bbca027b1a62de509d99f1a3572.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f8ca1d71e4d6c11c5209c9e66e5a8cc3',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/d5c04bad6c320f96108b3ebe9a6d78a0.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '36e576e41e25e0824ce801da76edbc7b',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/f6081915e0fdc1186d0e804ffa16b6be.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0cfe83a20b71ffb4b5b7eb7777a29384',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/4d9342a3889721d05ee77899b99e5a34.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b9296a381db5fa6d931ff6e5522da9f7',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/0e4cb566bd665e5b623be0f5ef47b8ff.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b6f848d57cb57e47309e8eab667cd3bf',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/60142d86630d8f6b9caa52b06825036d.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd41966aa501fd101982db64f8f2e93c2',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/03b1375223788c9caf1dd81932fd38c4.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5cbf3b00ee7a92d1e03ff7760e500721',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/bcc09e4fa05be3e147da6ff013069e04.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0fb1b798f7fa3c93fb09f3a8b32021a8',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/33bc86fab54cb872bcd56ac0d73cd605.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '53cb82a77178a6d8ed4c4e3421963ae6',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/a2b6ff84c1367f848c4dfeb17db4256e.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bcdc74d748bba500bffd3898486f5bcf',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/6ab99a91ddd256b513c2c211e45de5bf.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c0f8266aca7f77e21a3a63642e001d9d',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/4647335d12f83302d26b7d9a5755a1f0.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1b4aee1d9f7c9ec358ec9f318fe13a89',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/4e9dfecf4ccf8b70b7107041d3293a69.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a19ee17c71b49e260329cb76a490e235',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/46228bcda6c26fe877e2305639baacec.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '625a797030c9f982be1b0a12bece85a8',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/98dda4063864db20ce3eb1f3e9ac6222.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0bb017cc09fe0b93b13a4acd838b66f0',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/696120e4fab577b63daff5b0104d497f.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '197f3eeed6fd7d68c2d135a2a1ca570d',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/daac5f426a1253b7f77446ef98768088.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7ec6d99791384e74d8cf8f3b70c9071c',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/3a0a3c20beb710f0ecfffcf797860aff.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '26b970329afed74f01755100c0ea214a',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/19afd4a03020f7be887d419cf95b5b88.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f5db041afc25bf0d21eb285fec562fcd',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/287f4ddf7d7282a7428fd6bd30ff5728.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5383bf0857101266d47908b93705f996',
      'native_key' => 'manager_html5_cache',
      'filename' => 'modSystemSetting/f3fa3845bca9658fb66d80fa2a169463.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '76870686bc69be38d18a5b9274d8d931',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/f82b1154d8533db4ee142aa45eacfca3.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3cca32c902cf49131646bd26fb24cdfe',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/715e561a7354cad11f66e69f69c9fc4a.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '31de473b0243f7a7dcda3ecac81c8ea5',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/c34e24887750b3a26c1cd83027831b6b.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd8ebc29a20a2475506cf986e7242435',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/a036b9db397fd56323c246d3348c6568.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '37fee2c187fddcb5de13ef82ec4a8ad9',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/54532a2bd71e222d017019054670c4e4.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c79f4aeef81b668b07b92a94d7437198',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/491eadfcd46dc53c5036f2548a4d55ba.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b62eb0aea71bbc5589d5af64f8f255f',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/06096294c8a8a1805f386bc6b04b84f5.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '53b7df402e8abca57225764ac0c39a7c',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/842122c2a2e0fbd86d1f5b513b71379f.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0b36b641f88f1b968cf4c63ae42a9a27',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/3d092d1fe8974a68265a111e5dcbf8f3.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7828d92b721baeb5a7facd2d9e6743d2',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/1dfdcd6c63617641a0f866799320b651.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '57dbd4e3ba1f23215d630518c112cb93',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/4a6e3181a55f70dad0cd973d8d18a661.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c8802ec2ce7aff330c1665ce31c4a8d5',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/2eaca6fd4ddc11acce121914553d6b77.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4435eebde41a7810b598a39fe719ee3c',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'modSystemSetting/c36bdf0258f2eaa12888476a2fd557e9.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ada43e86c1781f349cf52a620073662d',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/79ed482908be1ced5a3d5543231be422.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9960f97f30b1b22e141dfbf3695704db',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/6c420881e8878b8edbb81d26e5d40c2a.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '349e5b7961ae144427a9e992a9f36e95',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/79b844f0391e169de02871fa8c00e2ca.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c3afff0afcdaafa2d2328a27a0328b92',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/e1716ba5b22fda8b78d70d40b17520a4.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '780c1254909a709265ee693d09c3f5f6',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/10d86e36dc8c2c82a01609ba019f3d08.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4bf81bfc1f8a1515250a80656a1ee091',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/a83dfb1dccd3c7ad3b742a3774e61e40.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8d196657ac3e9eecce64c62edf906c4d',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/ed964aa65167f90cd4cc82a3e8cd8539.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f04b3e74078b1888a8c6f6d18cada0e',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/89dd0aeda76b70a4244272c8f8188a1f.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e38df609378b8306fae328439e854e7c',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/16dd1a315902d72ab3dd489a4fafff95.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c8a91f0bb23bb8d07d71be5c1743954',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/64b1e84110f0ebcd215681236237ceef.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '09b9102c740c287d1abc97b934d0ea12',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/e7b7df9e5e02a6e9eb3fde30204c782a.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0be4b562df03a27c72b2d729fea4f7e3',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/fc57a054235925f8f301121dee06dcbf.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '487f93162908db0259d148912496af7d',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/fe6357046f05a3cc929552281143f9e4.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '136cc46584403407edb0b54bc97397a1',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/620f4b4a583148a8e25ce0f541ea7e56.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b5439754a802f09ef5d9d315f6bfe2c7',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/2071b6db96c311daa17bd3e4dfa09325.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c9339c05a207f12010446b076b51407e',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/d712619f7e92eaa03a406788c5c038f8.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0e72be1fea4d3ceb8a2f676d50a087d2',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/53f068a2968e4bde8ebfdbb5848edf51.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '462c7884ba58cf73e359ccd249c1dbbd',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/476c41b175abe74a8c20949a2bce8a7e.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e162b9c0258d22d88a8c767e3bb83691',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/909d3854761e77b575274bba50433548.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f4d841aa173639d57cf9b3f9dd459a57',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/5a2c2b1e6e67373ade5e0158d20e6e4a.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9d88f3868f1b42205aec3843d71da76c',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/5426a5c851fc1dd7bb3d5117648b6534.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b30642ee8c28d0fa781d7f1213465302',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/c6d034f07f041d028bbae3a5fbd50256.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a245937130d62901f595941068f57220',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/9fac3939a48c8790165168b182a0a54e.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a6ba663bc2b9f35a6996f32dbf85c6df',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/28148a8c2da4fbcbbcba74199f0c5709.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2e23900adec38c0bbfc6c66d0d76357d',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/36c0b7335f80cdb7886dcfb357fedbe7.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4e7f2c66b571b3b06e86fae0f7b56551',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/6cff1636db2790383dc64e71c84b80cf.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '912113ac9372b4086f7d0271db104fb3',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/d6f4c6ccaf91cedba4d999a22566f1af.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7fff7be2a71d9144e376351842f59e15',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/7f8c32a1886f65fc91975401fd791269.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5f621e907bdfc1635e19720f8fb74cc6',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/e6bd0420cc77afa35f0a147e3722e6e3.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '18e08e1685b8ad1a4ff3843c3ddcb8a4',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/fdfc585a4ac526838b792ae925dc3566.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a5208a8efe669b6314200aece74956ef',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/ac53b2062688b14d2e2688725a515f5f.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '699c14546be761473bbaddf1c6103c7d',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/2dc85ae14a2e0c3218993bdfacbec726.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '768aabb0d550083e5819541ba4b3b495',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/d1f4863527555b27181902207d0c30b6.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '279ae1d5f0ea90b6ff94644cc4fcc54e',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/8f72f14b6d6bb1a14bf0667d15a41f44.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '69f0521ffb7536267d4bd2f5c8862663',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/8d065a78d0529b304e25d37251ae0020.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd46751ed87ced01ac13d94686e1eda9e',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/eded84f1bee1f7d05327daa0c0ee2b2b.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '65cbb89dc9a4c76e339be5274f7af045',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/b5db78f13d8635647603aa355c9ecf5e.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cd23fadc4540820a65fec17d0ac69e15',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/a7b477d596a90fac294013cbbbbeaffa.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '792da8a346abf9410f9d419e1110b0d9',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/ab7bcf7eae4402d69dfa9f0efc6f3001.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '02cb31a26956d2ffc5a2983f5a1576fe',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/0dc933aee022b883e16d41c9a1da944e.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fed97d35e5ab2685546af5766774c290',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'modSystemSetting/0bb97becab22bc993bfdca93d527815e.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e6d358e80183ca00b0b8e190b11df479',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/abb7cff2884dbed9acc71e1bca6665a1.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e6314c1f75418db528529b055a41fbf5',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/8b05df46bd0011d855caefeaa69817d3.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9a1360d1b4d126145f1bf6df6c82d4d6',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/fba6b8255f9df611fa22c3210abc5a8f.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f57087b5d5a03adf681ff4169c327655',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/e6304ee6714e92d564f838c83d562a98.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f8e31d57a4b4ee1c6cf16f32e04961a',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/1007bf572acd27d1a3f14d130b0a50c6.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dcee8b7cdf80a8dc7be61a23c2e44535',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/da44760f06131886d373e5cb8f8cd1a1.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bc7ff04b0c559653b3ff002b27629fd5',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/40fc8f33c029127c09396f8e2c20aecf.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6d5517439517c7491a0633a26a368841',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/7fd0f13df34242702611cc4bcd390eb7.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2f0a584fd160567f6c0d6959bc4146ff',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/81c9e5846be91db33b9ce63fbca3c03c.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b40e3a463161a6dd06b1d1c9e4e1207e',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/e15d8c591c2aa104dcb61205c77cb67d.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b5de7a7c8dde8090b44e7e2e9aa0a260',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/2d179331ebc0508cabaa9df52585ee3e.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5d69b5d1e1deaf35eac6cbabbb62c10a',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/f55db91baa281390f4e8e64fb1d1bdba.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '41562a9351baa9bde52187e1255e5c9c',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/3da00b22d010b6a0d26c02f2b5d13e36.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cdb64d70027c824157003979d77e9463',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/54209b8cae3e89231efa5ae4a9f37ac2.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '86b6473d07ebd2718cc929f7126c1f2c',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/7cc4121162a84872e84b4dde15b2fc25.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8d1cda6b7a162654624ec067923e278a',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/9176798f891d739e6cd368f0059cd07f.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b467939c71630f8e41c7d5c502ed7739',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/6b63207fe4e7f8050c70fdda2de4f9b1.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a3c3cbf86f33fb75b4366d7085c09096',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/0d04da69fc5e7843fcff050978182ee1.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ad1ba711269c685e40632e6f9414b6ee',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/04caad7cd57e3878e991d8cb84cc0cc7.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '27531b6918625962d6e9b5d71f22ac36',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/84009cf358f842dedf88e9c3916fd0ce.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c03a794d8a76cad7b4d5774d1d176dd6',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/e5f1f7baebc4963f7ebff3ae72274eea.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '84c17e0c490eb67171ddbaeb51043729',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/332a5ac6ff5d9a4768838e06738922b1.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a19e4c5ed588e81f4b37a8d22f21eb3c',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/21b15ad0c646a8abba4d4d7b431c4f6c.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1fb859caed40a75a29b41d0a1a93a558',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/5e7c72ec093b84d0b95b2fda31a0c1f5.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '25cd075d4fad1aa8d9627456871f8306',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/320b08297d5a02bddd432d5aba347671.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bc2131a10b2a466f9620df284a6949ce',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/61dd713e8c1290d88b4419a683dd42ee.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '682d2968572b6423135ede237d6bad10',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/e8029dd0727c0b4276eb696602a6c5f4.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ad541e59675d901a41068174bdc6da3',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/37a1fe76ad3c7c6c2efdcb8a3a2ef5bf.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '641c2d611b0d4dce4369510ce3c20fe6',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/ba3305a2950098f35644d5b0c5aa3caf.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5f74408e362ef80550c648faed56e034',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/31b01c899e003c37a830c82749945960.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9d7af84201731951f62d20be1409a83f',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/eb74b7e20c27d08d1f11ed9facfdeaf0.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5afd6903194abaa9fdd7d55e1d16eede',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/34fb9c76f79b31df36ead91cdba87e97.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a948f045565246d51d792707b3f207e8',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/701b9a7e3fd5ea9d29ec21cbb9c9a9b2.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f3cfdf65d3f2f3c8d8fe511d8f675ead',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/b6e2f98dcf4fc4211fdd297b1fdeb115.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5b256799b2851d2031e3b9206566c99f',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/b930f1ab2b073f485a305fb650989b09.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c7606990191c7aaa38f132060e8e1c8b',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/5ff1f37e78634678ee18a5931b415575.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '69fc3f4016bd15769a9001beecd1ec5b',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/159dbc88c2d47c0bb9313be5783aafd9.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd933efbd7e9633402fb46f5f1cf5aacb',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/811538c632dbee2f9e300a5b2d449df3.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ca5719e6557a65d793fc8a6b33bda9e',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/308c7c977e79861629508ef22d82fadb.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '10e7f4c176ba243fd2038b8e7e4d9277',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/8eb6aead74176f9ed3b4bb2a4a588f5e.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6b7a57b7af40fd6c6ec82acabad35412',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/086ad175d0cfcf305821b21b784ff4e5.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e232994d4d98f0788f86ef545b366d83',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/7a10ed4b07b34712afa99a62266045fe.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ffe5b308fc7297a251d8ef0398bf7738',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/f0becb48764036caa7dff11da914146b.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c04f073b23f941436c8816a1c4a9249c',
      'native_key' => 'welcome_action',
      'filename' => 'modSystemSetting/161e4a247ff4cdc0e6fbe010ccbaa145.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '33e0d628b12277ed7b0b30b45cba609f',
      'native_key' => 'welcome_namespace',
      'filename' => 'modSystemSetting/c2779590428b55df38f35261955f28a5.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1a70621f32819ddd77b7c00af10726fe',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/4b0014120403262dd942a913076cb0d0.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e7a1028a1ef58d198bbffb9330919adc',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/dc14bb73b66c6a69dacf4a453deebedb.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ee7ca922819edb4946744bc0919e7c27',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/025bf74a3eb0def229c0c9c8e59bcb93.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '02b69cc8a15f563dc5bb5cd0902256e7',
      'native_key' => 'enable_gravatar',
      'filename' => 'modSystemSetting/4968da91fa89dd9dd75325e605a5d8bb.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'f17572365eaf331fea7bc6a9f43a45c1',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/ba524941ab0befeaa6524fb0bc927714.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '2f5ffbb08f5b720c4de4698db743df70',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/b1b35b87cf448df77b95f11bb268ab25.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '47aac324b50c936364a39ff836261b04',
      'native_key' => 1,
      'filename' => 'modUserGroup/b30309fbad2c7dd72bcb096cd18d8cdb.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => 'e9ee09db10d001ddf31a7a1e4f3192d3',
      'native_key' => 1,
      'filename' => 'modDashboard/fb2980a4878c3cd1fa0b6cb6c114c431.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => '06d93481e7d6d9ce5c095b6720347b8e',
      'native_key' => 1,
      'filename' => 'modMediaSource/9c1b1a679026c26af39db23f4c088fb5.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'f2a082e70c80c719ed22b1c2316b8c11',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/2fe15347e1417aa2e2efdb7ec3377d5b.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '7d81233536486573e85e65c2a0074175',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/193845fb3e762d0722d0f011f05a7d81.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '222832e58be1829b78855928cc306ecb',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/6fff9c0954f26cdaa2272a7ab38374c1.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '6d1864fbd865481eb4e6f08072381bb6',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/895a9b1ceb0bd0c5bd11fe76646b6296.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '9be7510cbeba1f6fa37a473effa30f8f',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/5ee458f61a7dfe7fc6e95b4c5dfdc464.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '3afc2e498d31b0b058cee9c4b68dc3eb',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/e4e681e4cd1b0058aaaadc17a54f959a.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => 'b2584cdf2b9b3ba367e099d6764065d6',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/0afeff9da1fc2e3db19f505523a9e5c2.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'eafa1066d3ad8d41f2a2f5225469f26e',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/1759da4d0aa0f9c56e7c4d81d248d221.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'a8abb67d5175adfbeb1db262cb3c5658',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/d6271a399da362f7fb6bdb7103d3d431.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '93c2517b8d4fc6f15fd1a06dc629368b',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/1bf728b9b34a5fa28adce8fe66d65242.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '190d19a06ab666d336643f3cf5740cbe',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/ab03baff811648a957233454568e730a.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '658c48057339b94f57781cfddc95ecac',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/61eeb253e2ad0c51a5a2e4a504f83bae.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'b47ab2681e7a2cdda98c96c0644a3e63',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/7635e2955865a44a5dd24830406d4f3b.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '5fb245aed3c05ff42831612b8f0d7ba0',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/e46778c9307cd8c6e283a9fe281188f8.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'c9ddb29a87df36fd4d701a9c5ae52878',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/0489d676073c79018af45b8567e994c5.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '1cd91d1f2c6731467c743b15f1fcf067',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/769075cd904b71bfb350b4204115b851.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'd65c24b27ecad97de13c2ab37fbf1fb1',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/3c22f2d04a340a30c99d65b7d9e38cee.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '6aa4ad2c76ba06a88e0895453f45f914',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/6ecc758811513f8415b8d963e2800172.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'dd09136eee1b8570929e026d802d3532',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/f59e02f86b80a90289e92f71bd3b8598.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'f853a73d166b75cd7f5fc7ee0605703e',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/5770f6f05220112b1e4c401bd73f2f34.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'e025a2ba478f4d8e74f3ee355d383401',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/698e26ae7f5b0a3e45a6998dc0dc7c30.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '143ec1bafd213e31127a44b8e4578bed',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/74bc131c168c5d9c438f9a18ff8f5ab2.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'd3fc7bf8b4c83522edb224822f268a26',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/6ae06f7d9303035e575d9a3c0d1ca49b.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'baac98f5759af27c59f3c75ae7798766',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/840c70c5575e0fa1e63b595c0020a510.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'd7ac8b7bf0494cc6671e8bd7b17490df',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/e9fad7d664718f2363a0216d13ccbe1c.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '98fdde59b446ad53ffffdb14828283d8',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/ec9cd8f94df268546401fbf2fad1e85b.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '710927a1ebff284ad29d64851012a61a',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/d1299e10de225399396c358bec1761fb.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '1478a98bc7e35c2a8afbb8b7c2f30e33',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/8519f5a8d06fe18498bedbb6bc797031.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '89cd033491ad3055fe03eee3325e92c8',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/f359a776d6bae456e781e09aa18429eb.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '45da09d971bf3cc11422ea725bea1040',
      'native_key' => 'web',
      'filename' => 'modContext/23da436d779952fd34e02e8cff13c1bf.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => 'ba3ec854a58c25ed1db11e1db729a8f1',
      'native_key' => 'mgr',
      'filename' => 'modContext/1e7cadee1e19689e1dfd44b3c280baa6.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '26c5bd209797d448d772cd6b04497c0b',
      'native_key' => '26c5bd209797d448d772cd6b04497c0b',
      'filename' => 'xPDOFileVehicle/b8dcf307a5097cb021909d6058d83e69.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '95c5885419e49106371ead512da9043a',
      'native_key' => '95c5885419e49106371ead512da9043a',
      'filename' => 'xPDOFileVehicle/16f30a29014b916ad21ef91acef30faf.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '948e184b87cd9988ad75a8541a87a1b7',
      'native_key' => '948e184b87cd9988ad75a8541a87a1b7',
      'filename' => 'xPDOFileVehicle/d2b52f0039e257e921d013eb43169807.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'daa4ec693810cbe4c02410abf6e090c8',
      'native_key' => 'daa4ec693810cbe4c02410abf6e090c8',
      'filename' => 'xPDOFileVehicle/ca23c2c5cf16db11429bb0388da7504d.vehicle',
    ),
  ),
);